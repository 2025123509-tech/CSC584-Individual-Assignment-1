# CSC584 Individual Assignment 1: Personal Profile Web Application

A simple personal profile application. It collects profile details in an HTML form, sends them to a Java Servlet with HTTP POST, and displays the submitted information on a JSP page.

## Technologies

- HTML5 and CSS
- Java Servlet API
- JavaServer Pages (JSP)
- NetBeans IDE 8.2
- GlassFish Server 4.1.1 (Java EE 7 Web)

## Project flow

1. `web/index.html` displays the profile form.
2. The form submits its fields to `ProfileServlet` using HTTP POST.
3. `src/java/ProfileServlet.java` reads the submitted values and forwards the request to `web/profile.jsp`.
4. `web/profile.jsp` displays the submitted profile. It escapes HTML special characters before displaying user-entered text.

No database is required.

## Run in NetBeans

1. Open this project in NetBeans IDE 8.2.
2. Make sure GlassFish Server 4.1.1 is registered and running.
3. Right-click the project and choose **Run**.
4. Open the project URL shown by NetBeans (usually `http://localhost:8080/CSC584PersonalProfile/`).
5. Fill in the form and select **Create My Profile**.

## Screenshots

- `screenshots/profile-form.png` shows the blank profile form.
- `screenshots/submitted-profile.png` shows the submitted profile output.
