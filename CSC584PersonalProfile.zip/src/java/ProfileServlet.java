import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ProfileServlet", urlPatterns = {"/ProfileServlet"})
public class ProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        request.setAttribute("fullName", request.getParameter("fullName"));
        request.setAttribute("studentId", request.getParameter("studentId"));
        request.setAttribute("programme", request.getParameter("programme"));
        request.setAttribute("email", request.getParameter("email"));
        request.setAttribute("hobbies", request.getParameter("hobbies"));
        request.setAttribute("introduction", request.getParameter("introduction"));

        RequestDispatcher dispatcher = request.getRequestDispatcher("/profile.jsp");
        dispatcher.forward(request, response);
    }
}
