<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%!
    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
%>
<%
    String fullName = escapeHtml((String) request.getAttribute("fullName"));
    String studentId = escapeHtml((String) request.getAttribute("studentId"));
    String programme = escapeHtml((String) request.getAttribute("programme"));
    String email = escapeHtml((String) request.getAttribute("email"));
    String hobbies = escapeHtml((String) request.getAttribute("hobbies"));
    String introduction = escapeHtml((String) request.getAttribute("introduction"));
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><%= fullName %> | Personal Profile</title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; padding: 32px 16px; font-family: Arial, sans-serif; color: #243047; background: #eef3fb; }
        main { max-width: 680px; margin: 0 auto; padding: 32px; background: #fff; border-radius: 16px; box-shadow: 0 12px 32px rgba(27, 50, 90, .12); }
        h1 { margin-top: 0; color: #224c92; }
        .detail { padding: 14px 0; border-bottom: 1px solid #e5eaf2; }
        .detail strong { display: block; margin-bottom: 6px; color: #52627b; }
        .value { white-space: pre-wrap; overflow-wrap: anywhere; }
        a { display: inline-block; margin-top: 24px; color: #2457a6; font-weight: 700; }
    </style>
</head>
<body>
    <main>
        <h1>Personal Profile</h1>
        <p>Here is the profile information you submitted.</p>
        <div class="detail"><strong>Full Name</strong><div class="value"><%= fullName %></div></div>
        <div class="detail"><strong>Student ID</strong><div class="value"><%= studentId %></div></div>
        <div class="detail"><strong>Programme</strong><div class="value"><%= programme %></div></div>
        <div class="detail"><strong>Email</strong><div class="value"><%= email %></div></div>
        <div class="detail"><strong>Hobbies</strong><div class="value"><%= hobbies %></div></div>
        <div class="detail"><strong>Self-Introduction</strong><div class="value"><%= introduction %></div></div>
        <a href="index.html">Edit my profile</a>
    </main>
</body>
</html>
